export class Month {
  constructor(public val: number, public name: string) { }
}
