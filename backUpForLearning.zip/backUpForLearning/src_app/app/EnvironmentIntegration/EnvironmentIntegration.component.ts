import { Component, AfterViewInit , Pipe } from '@angular/core';
import { NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { AppService }  from  '../app.service';
import { Projects } from '../projects';
import { Http , Response,Headers } from '@angular/http'; 
import { Observable } from 'rxjs/Observable'; 
import { OnInit } from '@angular/core';
import 'rxjs/add/operator/map';  
import { Projectdetails } from '../projectdetails';
import { Month } from '../month';
import { DateService } from '../dateservice';
import { CvsBranchProjects } from '../cvsbranchProjects';
import { SearchFilterPipe } from '../Filters/search-filter.pipe';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import { Environment } from '../environment';
import { RxEnvService } from '../rxenvservice';
import {Subscription} from "rxjs";

@Component({

    templateUrl: './EnvironmentIntegration.component.html',
    styleUrls: ['../app.component.css'],
    providers: [AppService, DateService, RxEnvService]

})

export class EnvironmentIntegrationComponent implements OnInit,AfterViewInit{

    caretFlag: boolean = true;

    arrowChange() {
        this.caretFlag = !this.caretFlag;
    }

  showspinner:boolean;
  submitServiceResponse:any;
  applicationList: Environment[];
  clusterList : Environment[];
  actionList : Environment[];
  formRxEnv: string;
  formRxHcEnv: string;
  formRxPsEnv: string;
  formRxLiteEnv: string;
  formRxWsEnv: string;
  itEnvName: string;
  responseSuccessStatus : boolean;
  responseFailureStatus : boolean;
  responseMessage : string;
  application : string;
  cluster : string;
  action : string;

constructor(private appservice: AppService,private dateservice:DateService, private envservice: RxEnvService, fb: FormBuilder){
  this.showspinner = false;
  this.responseSuccessStatus = false;
  this.responseFailureStatus = false;
  this.responseMessage = '';
  this.applicationList = envservice.getApplications();
  this.actionList = envservice.getActions();
}


ngOnInit() : void { 
     
} 

ngAfterViewInit():void{
}


rxSubmit(){
      this.showspinner = true;
      this.appservice.getRxEnvParams(this.application, this.cluster, this.action)
      .subscribe((response) => {this.submitServiceResponse = response,  this.responseSuccessStatus = (response.status == 'Success'), this.responseFailureStatus = (response.status == 'Failure'), this.responseMessage = response.message, this.showspinner = false}); 
       
  };

onSelectApplication(application : string){
  this.application = application;
  this.clusterList = this.envservice.getCluster(application);
  this.action=null;
}
onSelectCluster(cluster : string){
  this.cluster = cluster;
}
onSelectAction(action : string){
  this.action = action;
}
displaySubmitButton(){
    if(this.application !=null && this.cluster != null && this.action !=null)
      return false;
    else
      return true;
    
}

resetIntervalCount(){
  this.responseSuccessStatus = false;
  this.responseFailureStatus = false;
}

}
