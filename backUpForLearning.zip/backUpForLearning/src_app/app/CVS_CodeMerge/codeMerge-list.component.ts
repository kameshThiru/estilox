import { Component, AfterViewInit , Pipe } from '@angular/core';
import { NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { AppService }  from  '../app.service';
import { Projects } from '../projects';
import { Http , Response,Headers } from '@angular/http'; 
import { Observable } from 'rxjs/Observable'; 
import { OnInit } from '@angular/core';
import 'rxjs/add/operator/map';  
import { Projectdetails } from '../projectdetails';
import { Month } from '../month';
import { DateService } from '../dateservice';
import { CvsBranchProjects } from '../cvsbranchProjects';
import { SearchFilterPipe } from '../Filters/search-filter.pipe';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';



@Component({
  templateUrl: './codeMerge.component.html',
  styleUrls: ['../app.component.css'],
  providers: [AppService,DateService]
})

export class CodeMergeComponent implements OnInit,AfterViewInit {

  years: number[] =[];
  year : number;
  searchResult: string = '';
  fsrProjectslist:any[];
  relProjectslist:any[];
  isfsrlistDisplay:boolean;
  isrellistDisplay:boolean;
  isSelectedServer:boolean;
  projectType:string;
  projectslist:any[];
  startDate:any;
  fechaFin: any;
  FromEndDate:any;
  ToEndDate:any;
  mergeDetail:Projectdetails;
  projectname:string[];
  category:string;
  fromBranchMonths:Month[];
  toBranchMonths :Month[];
  fromBranchmonth:string;
  fromBranchyear:number;
  toBranchmonth:string;
  toBranchyear:number;
  cvsProjectReteriveData:any;
  showspinner:boolean;
  submitServiceResponse:any;
  selectAllfsr:any;
  selectAllrel:any;
  mergeForm:any;

constructor(private appservice: AppService,private dateservice:DateService,fb: FormBuilder){
  this.projectname = [];
  this.fromBranchMonths = this.dateservice.getMonths();
  this.showspinner = false;
  this.isfsrlistDisplay = false;
  this.isrellistDisplay = false;
  this.searchResult = "";
  this.mergeForm = fb.group({

      'optradio' : [null, Validators.required]
    })
}


ngOnInit() : void { 
     this.startDate = new Date();
     this.getYear();
} 

ngAfterViewInit():void{
     }

getServercategory():void{
    this.projectname = [];
    this.searchResult = "";
    this.projectType = "";
    this.isrellistDisplay = false;
    this.isfsrlistDisplay = false;
    this.isSelectedServer = true;
}

getDesktopCategory():void{
    this.projectname = [];
    this.searchResult = "";
    this.projectType = "rel";
    this.isrellistDisplay = false;
    this.isfsrlistDisplay = false;
    this.isSelectedServer = false;
    this.category="desktop";
    this.displayRELprojectList();
}

getFSRProjects():void{
    this.showspinner = true;
    this.cvsProjectReteriveData = this.fromBranchmonth+"_"+this.fromBranchyear+"_fsr";
    console.log(this.category);
    console.log(this.cvsProjectReteriveData);
    this.appservice.getBranchProjects(this.cvsProjectReteriveData,this.category) 
    .subscribe((cvsprojects) => { this.fsrProjectslist = cvsprojects.cvsProjectList,this.showspinner = false,this.isfsrlistDisplay = true});
};

getRELProjects():void{
   this.showspinner = true;
   this.cvsProjectReteriveData = this.fromBranchmonth+"_"+this.fromBranchyear+"_rel";
    this.appservice.getBranchProjects(this.cvsProjectReteriveData,this.category)
    .subscribe((cvsprojects) => { this.relProjectslist = cvsprojects.cvsProjectList,this.showspinner = false,this.isrellistDisplay = true});
};

displayFSRprojectList(){
    this.projectname = [];
    this.searchResult = "";
    this.getFSRProjects();
    this.isrellistDisplay = false;
};

displayRELprojectList(){
    this.projectname = [];
    this.searchResult = "";
    this.getRELProjects();
    this.isfsrlistDisplay = false;
};

displaySubmitButton(){
    if(this.projectType){
      return false;
    }else if(this.category === 'desktop'){
      return false;
    }else{
      return true;
    }
}

updateCheckedOptions(chBox, event) {
    var cbIdx = this.projectname.indexOf(chBox);
    if(event.target.checked) {
         if(cbIdx < 0 )
           this.projectname.push(chBox.replace(",", " "));
    } else {
         if(cbIdx >= 0 )
           this.projectname.splice(cbIdx,1);
     }
      console.log(this.projectname);  
      console.log(this.projectType);
  };

submit(){
      this.showspinner = true;
      var fromdt = (this.fromBranchmonth+"_"+this.fromBranchyear+"_"+this.projectType).toLowerCase();
      var todt = (this.toBranchmonth+"_"+ this.toBranchyear+"_"+this.projectType).toLowerCase();
      var tagName = "TAG_"+fromdt;
      this.mergeDetail = new DataNode(fromdt,todt,this.projectType,tagName,this.projectname);
      console.log("fromdt = "+fromdt+"  todt = "+todt);
      console.log("projectType = "+this.projectType);
      console.log(JSON.stringify(this.mergeDetail));
      this.appservice.submitProjectDetails(this.mergeDetail)
       .subscribe((response) => {this.submitServiceResponse = response,  this.showspinner = false});
      
  };

getYear(){
        var today = new Date();
        this.year = today.getFullYear();        
        for(var i = (this.year-1); i <= this.year+1; i++){
        this.years.push(i);
      }
    };

onSelectFromMonth(val) {
    this.toBranchMonths = this.dateservice.getMonths();
    this.fromBranchmonth = val;
   
   }

onSelectFromYear(val) {
    this.fromBranchyear = val;
   }

onSelectToMonth(val) {
    this.toBranchmonth = val;
   }
onSelectToYear(val) {
    this.toBranchyear = val;
   }

checkAllFSR(ev) {
  this.selectAllfsr =  ev.target.checked;
  if(this.selectAllfsr){
     this.projectname = [];
    for(var i=0;i<this.fsrProjectslist.length;i++){
      this.projectname.push(this.fsrProjectslist[i].replace(",", " "));
    }
  }else{
    this.projectname = [];
  }
 }


checkAllREL(ev) {
  this.selectAllrel =  ev.target.checked;
  if(this.selectAllrel){
     this.projectname = [];
    for(var i=0;i<this.relProjectslist.length;i++){
      this.projectname.push(this.relProjectslist[i].replace(",", " "));
    }
  }else{
    this.projectname = [];
  }
}


  model: NgbDateStruct;
  date: {year: number, month: number};

}

class DataNode implements Projectdetails {
    mergeFrom: string;
    mergeTo: string;
    branchName: string;
    tagName: string;
    projectNamesList: string[];

    constructor(mergeFrom: string, mergeTo: string, branchName: string,tagName: string,projectNamesList?: string[]) {
        this.mergeFrom = mergeFrom;
        this.mergeTo = mergeTo;
        this.branchName = branchName;
        this.tagName = tagName;
        this.projectNamesList = projectNamesList || [];
    }

    addNode(projectNamesList: string): void {
        this.projectNamesList.push(name);
    }

}