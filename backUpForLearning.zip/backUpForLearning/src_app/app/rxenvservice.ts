import { Injectable } from '@angular/core';
import {Environment} from './environment';

@Injectable()
export class RxEnvService {

  getApplications(){
    return [
         new Environment(1,'RX'),
         new Environment(2,'RXHC'),
         new Environment(3,'RXPS'),
         new Environment(4,'RXLITE'),
         new Environment(5,'RXWS')
    ];
  }
  getActions(){
    return [
         new Environment(1,'DeployAndStart'),
         new Environment(2,'StopAndStart')
    ];
  }
  getCluster(applicatinName:String) {
    if(applicatinName === "RX"){
      return [
         new Environment(1,'RX1'),
         new Environment(2,'RX2'),
         new Environment(3,'RX3'),
         new Environment(4,'RX4'),
         new Environment(5,'RX6'),
         new Environment(6,'RX8')
    ];
  }
    else if(applicatinName === "RXWS") {
       return [ new Environment(1,'IT')
    ];
  }      
    else
    return [
         new Environment(1,'IT'),
         new Environment(2,'ST')
    ];
  }
}