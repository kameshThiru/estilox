import { Component } from '@angular/core';
import { Month } from '../month';
import { DateService } from '../dateservice';
import { AppService }  from  '../app.service';
import { BranchDetails } from '../branchDetails';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
@Component({
    templateUrl: 'branching.component.html',
    styleUrls: ['../app.component.css'],
    providers: [AppService,DateService]
})

export class BranchingComponent{
    year : number;
    years: number[] =[];
    fromBranchMonths:Month[];
    fromBranchyear:number;
    toBranchMonths :Month[];
    fromBranchmonth:string;
    toBranchmonth:string;
    startDate:any;
    toBranchyear:number;
    projectType:string;
    submitServiceResponse:any;
    branchDetail:BranchDetails;
    showspinner:boolean;
    isSelectedServer:boolean;
    category:string;
    isSuccess:boolean;
    constructor(private appservice: AppService,private dateservice:DateService,fb: FormBuilder){
        this.fromBranchMonths = this.dateservice.getMonths();
    }
    ngOnInit() : void { 
        this.startDate = new Date();
        this.getYear();
    }
    getYear(){
        var today = new Date();
        this.year = today.getFullYear();        
        for(var i = (this.year-1); i <= this.year+1; i++){
            this.years.push(i);
        }
    }
    onSelectToMonth(val) {
        this.toBranchmonth = val;
    }
    onSelectFromMonth(val) {
        this.toBranchMonths = this.dateservice.getMonths();
        this.fromBranchmonth = val;
    }
    onSelectFromYear(val) {
        this.fromBranchyear = val;
    }
    onSelectToYear(val) {
        this.toBranchyear = val;
    }
    getServercategory():void{
        this.projectType = "";
        this.isSelectedServer = true;
    }

    getDesktopCategory():void{
        this.projectType = "";
        this.isSelectedServer = false;
    }
    displaySubmitButton(){
        if(this.projectType){
        return false;
        }else if(this.category === 'desktop'){
        return false;
        }else{
        return true;
        }
    }
    submit(){
        this.showspinner = true;
        var fromdt = (this.fromBranchmonth+"_"+this.fromBranchyear+"_"+this.projectType).toLowerCase();
        var todt = (this.toBranchmonth+"_"+ this.toBranchyear+"_"+this.projectType).toLowerCase();
        this.branchDetail = new DataNode(fromdt,todt,this.projectType,this.category);
        console.log("From Date :: "+fromdt);
        console.log("To Date :: "+todt);
        console.log("Category :: "+this.category);
        this.appservice.submitBranchDetails(this.branchDetail).subscribe((response) => {this.submitServiceResponse = response,  this.showspinner = false});
    }
}

class DataNode implements BranchDetails {
    branchFrom: string;
    branchTO: string;
    branchName: string;
    categoryName : string;
    

    constructor(branchFrom: string, branchTo: string, branchName: string,categoryName: string) {
        this.branchFrom = branchFrom;
        this.branchTO = branchTo;
        this.branchName = branchName;
        this.categoryName = categoryName;
    }

}