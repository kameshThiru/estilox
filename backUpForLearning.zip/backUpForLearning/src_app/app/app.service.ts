import { Injectable, ErrorHandler } from '@angular/core';
import { Http , Response , Headers , RequestOptions} from '@angular/http'; 
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'; 
import 'rxjs/add/operator/do'; 
import 'rxjs/add/operator/catch';
import { Projects } from './projects';
import { CvsBranchProjects } from './cvsbranchProjects';
import { Projectdetails } from './projectdetails';
import { BranchDetails } from './branchDetails';

@Injectable()
export class AppService {

private IT_ENVIRONMENT_URL = 'http://lxdenvmtc157.dev.qintra.com:13001/RxBuildAutomationTool/Automation/Cvs/itDeployment?environmentType=';
private PROP_COMPARISON_URL = 'http://lxdenvmtc157.dev.qintra.com:13001/RxBuildAutomationTool/Automation/Cvs/getPropertyParam?environment=';
private CVS_PROJECT_RETERIVE_URL = 'http://lxdenvmtc157.dev.qintra.com:13001/RxBuildAutomationTool/Automation/Cvs/getProjectsList?branchName=';
private CVS_MERGE_URL = "http://lxdenvmtc157.dev.qintra.com:13001/RxBuildAutomationTool/Automation/Cvs/doMerge";
private CVS_BRANCH_URL = "http://lxdenvmtc157.dev.qintra.com:13001/RxBuildAutomationTool/Automation/Cvs/doBranch";

  constructor(
    private http:Http
  ) { }

  getBranchProjects(cvsProjectReteriveData,category):Observable<CvsBranchProjects>{
    let headers = new Headers();
    headers.set('Access-Control-Allow-Origin', 'http://localhost:4200');
    console.log(category);
    return this.http.get(this.CVS_PROJECT_RETERIVE_URL+""+cvsProjectReteriveData+"&category="+category)
    .map((response: Response) => <CvsBranchProjects> response.json()) 
    .do(data => console.log((data))); 
  }

 getPropertyParams(environment,branchMonth,branchYear):Observable<CvsBranchProjects>{
    let headers = new Headers();
    headers.set('Access-Control-Allow-Origin', 'http://localhost:4200');
    console.log("environment: "+environment+", branchMonth: "+branchMonth+", branchYear: "+branchYear);
    return this.http.get(this.PROP_COMPARISON_URL+""+environment+"&branchMonth="+branchMonth+"&branchYear="+branchYear)
    .map((response: Response) => <CvsBranchProjects> response.json()) 
    .do(data => console.log((data))); 
  }

  getRxEnvParams(environmentType, environmentName, action):Observable<CvsBranchProjects>{
    let headers = new Headers();
    headers.set('Access-Control-Allow-Origin', 'http://localhost:4200');
    console.log("environmentType: "+environmentType+", environmentName: "+environmentName+" ,action: "+action);
    return this.http.get(this.IT_ENVIRONMENT_URL+""+environmentType+"&environmentName="+environmentName+"&action="+action)
    .map((response: Response) => <CvsBranchProjects> response.json()) 
    .do(data => console.log((data))); 
  }

  submitProjectDetails(projectDetails:Projectdetails): Observable<Projectdetails> {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.CVS_MERGE_URL, projectDetails, options)
               .map(response => response.json())
               .do(data => console.log((data)))
               .catch(this.handleErrorObservable);
  }

  submitBranchDetails(branchDetails:BranchDetails): Observable<BranchDetails> {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.CVS_BRANCH_URL,branchDetails,options)
                .map(response => response.json())
                .do(data => console.log((data)))
                .catch(this.handleErrorObservable);
  }

  private handleErrorObservable (error: Response | any) {
	  console.error(error.message || error);
	  return Observable.throw(error.message || error);
  }

}
