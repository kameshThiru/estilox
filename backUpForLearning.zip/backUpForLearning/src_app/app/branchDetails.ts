export interface BranchDetails{
    branchFrom : string;
    branchTO : string;
    branchName : string;
    categoryName : string;
}