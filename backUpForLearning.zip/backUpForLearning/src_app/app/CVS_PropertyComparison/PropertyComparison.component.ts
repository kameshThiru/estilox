import { Component, AfterViewInit , Pipe } from '@angular/core';
import { NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { AppService }  from  '../app.service';
import { Projects } from '../projects';
import { Http , Response,Headers } from '@angular/http'; 
import { Observable } from 'rxjs/Observable'; 
import { OnInit } from '@angular/core';
import 'rxjs/add/operator/map';  
import { Projectdetails } from '../projectdetails';
import { Month } from '../month';
import { DateService } from '../dateservice';
import { CvsBranchProjects } from '../cvsbranchProjects';
import { SearchFilterPipe } from '../Filters/search-filter.pipe';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import { Environment } from '../environment';
import { EnvService } from '../envservice';


@Component({

    templateUrl: './PropertyComparison.component.html',
    styleUrls: ['../app.component.css'],
    providers: [AppService, DateService, EnvService]

})

export class PropertyComparisonComponent implements OnInit,AfterViewInit{

    caretFlag: boolean = true;

    arrowChange() {
        this.caretFlag = !this.caretFlag;
    }

  years: number[] =[];
  year : number;
  projectname:string[];
  fromBranchMonths:Month[];
  fromBranchmonth:string;
  fromBranchyear:number;
  showspinner:boolean;
  submitServiceResponse:any;
  envList: Environment[];
  formEnv: string;

constructor(private appservice: AppService,private dateservice:DateService, private envservice: EnvService, fb: FormBuilder){
  this.projectname = [];
  this.fromBranchMonths = this.dateservice.getMonths();
  this.showspinner = false;
  this.envList = this.envservice.getEnvs(); 
}


ngOnInit() : void { 
     this.getYear();
} 

ngAfterViewInit():void{
     }

displaySubmitButton(){
    if(this.fromBranchmonth !=null && this.fromBranchyear != null && this.formEnv !=null)
      return false;
    else
      return true;
    
}
onSelectFromYear(val) {
    this.fromBranchyear = val;
   }
submit(){
        this.showspinner = true;
       this.appservice.getPropertyParams(this.formEnv, this.fromBranchmonth, this.fromBranchyear)
       .subscribe((response) => {this.submitServiceResponse = response,  this.showspinner = false});
      
  };

getYear(){
        var today = new Date();
        this.year = today.getFullYear();        
        for(var i = (this.year-1); i <= this.year+1; i++){
        this.years.push(i);
      }
    };

onSelectFromMonth(val) {
    this.fromBranchmonth = val;
   
   }

onSelectFromEnvironment(val) {
    this.formEnv = val;
   }


  model: NgbDateStruct;
  date: {year: number, month: number};

}
