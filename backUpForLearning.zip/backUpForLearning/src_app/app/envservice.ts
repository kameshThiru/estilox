import { Injectable } from '@angular/core';
import {Environment} from './environment';

@Injectable()
export class EnvService {
  getEnvs() {
    return [
         new Environment(1,'all'),
         new Environment(2,'wst'),
         new Environment(3,'val'),
         new Environment(4,'prod'),
    ];
  }
}