import { Injectable } from '@angular/core';
import { Month } from './month';


@Injectable()
export class DateService {
  getMonths() {
    return [
         new Month(1,'Jan'),
         new Month(2,'Feb'),
         new Month(3,'Mar'),
         new Month(4,'Apr'),
         new Month(5,'May'),
         new Month(6,'Jun'),
         new Month(7,'Jul'),
         new Month(8,'Aug'),
         new Month(9,'Sep'),
         new Month(10,'Oct'),
         new Month(11,'Nov'),
         new Month(12,'Dec')
    ];
  }

}