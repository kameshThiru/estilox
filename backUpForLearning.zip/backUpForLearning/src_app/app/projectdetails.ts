export interface Projectdetails {
    mergeFrom: string;
    mergeTo: string;
    branchName: string;
    tagName: string;
    projectNamesList: string[];
}
