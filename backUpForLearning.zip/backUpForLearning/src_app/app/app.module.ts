import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { SearchFilterPipe } from './Filters/search-filter.pipe';

import { appRouterModule } from './app.routes';
import { BranchingComponent } from './CVS_Branching/branching-list.component';
import { CodeMergeComponent } from './CVS_CodeMerge/codeMerge-list.component';
import { PropertyComparisonComponent } from './CVS_PropertyComparison/PropertyComparison.component';
import { EnvironmentIntegrationComponent } from './EnvironmentIntegration/EnvironmentIntegration.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    NgbModule.forRoot(),
    appRouterModule
  ],
  declarations: [
    AppComponent,
    BranchingComponent,
    CodeMergeComponent,
    SearchFilterPipe,
    PropertyComparisonComponent,
    EnvironmentIntegrationComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
