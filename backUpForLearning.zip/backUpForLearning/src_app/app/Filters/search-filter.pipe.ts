import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(items: any, args: string): any {
        return  args ? items.filter(item => (item.split(' ')[1]).toString().toLowerCase().indexOf(args.toString().toLowerCase()) !== -1): items;

  }
}
