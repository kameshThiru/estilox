export class Environment {
    constructor(public slno:number, public envName: String){}
}