export interface Projects {
Projectfsr: any; 
Projectrel: any; 
}
