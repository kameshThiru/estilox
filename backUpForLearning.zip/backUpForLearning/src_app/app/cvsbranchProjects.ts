export interface CvsBranchProjects {
status:any;
message:any;
cvsProjectList:any[];
}
