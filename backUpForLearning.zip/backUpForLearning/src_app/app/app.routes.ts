import { Routes, RouterModule } from '@angular/router';
import { BranchingComponent } from './CVS_Branching/branching-list.component';
import { CodeMergeComponent } from './CVS_CodeMerge/codeMerge-list.component';
import { PropertyComparisonComponent } from './CVS_PropertyComparison/PropertyComparison.component';
import { EnvironmentIntegrationComponent } from './EnvironmentIntegration/EnvironmentIntegration.component';



export const routes: Routes = [
   { path: '', component: BranchingComponent },
  { path: 'branching', component: BranchingComponent },
  { path: 'codemerge', component: CodeMergeComponent },
  { path: 'propcomparison', component: PropertyComparisonComponent },
  { path: 'envintegration', component: EnvironmentIntegrationComponent }
];


export const appRouterModule = RouterModule.forRoot(routes);